# ReyOptimazor

A modern Android performance-control dashboard inspired by the general category of Android optimizer apps.

Features:
- Modern dark RO interface
- Smooth Mode shortcut to system display settings
- Game Mode shortcut
- Touch settings shortcut
- Thermal status
- Refresh-rate readout
- Network transport readout
- Apps and Settings shortcuts
- Shizuku availability + permission flow
- Android 16-friendly architecture
- Java/Kotlin JVM target 17

Shizuku:
This app integrates the official Shizuku API/provider. Shizuku must be installed and started by the user before privileged access can work. On Android 11+, Shizuku can be started using Wireless debugging according to its official documentation.

Safety scope:
This project focuses on legitimate device performance and system controls. It does not implement aim assist, auto-aim, memory injection, anti-cheat bypass, or modification of another game's input pipeline.

Build:
- compileSdk 35
- targetSdk 35
- minSdk 31
- AGP 8.7.3
- Kotlin 2.0.21
- JDK 17
- Gradle 8.11.1
