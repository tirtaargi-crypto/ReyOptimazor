package com.reyoptimazor.app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Display
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var thermal: TextView
    private lateinit var display: TextView
    private lateinit var network: TextView
    private lateinit var log: TextView

    private val shizukuRequestCode = 2201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.statusText)
        thermal = findViewById(R.id.thermalText)
        display = findViewById(R.id.displayText)
        network = findViewById(R.id.networkText)
        log = findViewById(R.id.logText)

        refreshStatus()

        findViewById<Button>(R.id.smoothButton).setOnClickListener {
            openDisplaySettings()
            log.text = "Smooth Mode: opened system display controls.\nFor maximum smoothness, select the highest stable refresh rate supported by your device."
        }

        findViewById<Button>(R.id.gameButton).setOnClickListener {
            openGameModeSettings()
        }
        findViewById<Button>(R.id.touchButton).setOnClickListener {
            openTouchSettings()
        }
        findViewById<Button>(R.id.displayButton).setOnClickListener {
            openDisplaySettings()
        }
        findViewById<Button>(R.id.thermalButton).setOnClickListener {
            refreshStatus()
            Toast.makeText(this, "Thermal status refreshed", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.networkButton).setOnClickListener {
            refreshStatus()
            Toast.makeText(this, "Network status refreshed", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.appsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))
        }
        findViewById<Button>(R.id.shizukuButton).setOnClickListener {
            handleShizuku()
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun refreshStatus() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val thermalStatus = pm.currentThermalStatus
        val thermalName = when (thermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unknown"
        }
        thermal.text = "Thermal: $thermalName"

        val wm = getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        val refresh = wm.defaultDisplay.refreshRate
        display.text = "Display: ${"%.0f".format(refresh)} Hz"

        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi‑Fi"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
            else -> "Offline / unknown"
        }
        network.text = "Network: $net"

        val shizuku = if (Shizuku.pingBinder()) "Shizuku: Connected" else "Shizuku: Not connected"
        status.text = "Performance control • $shizuku"
    }

    private fun handleShizuku() {
        if (!Shizuku.pingBinder()) {
            log.text = "Shizuku is not running.\nStart Shizuku first, then return here and tap Shizuku again."
            Toast.makeText(this, "Shizuku is not running", Toast.LENGTH_SHORT).show()
            return
        }

        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            log.text = "Shizuku access: GRANTED.\nReyOptimazor can use permitted Shizuku operations."
            Toast.makeText(this, "Shizuku permission already granted", Toast.LENGTH_SHORT).show()
        } else {
            Shizuku.requestPermission(shizukuRequestCode)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == shizukuRequestCode) {
            refreshStatus()
            val granted = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            log.text = if (granted) {
                "Shizuku access: GRANTED.\nPermission setup completed."
            } else {
                "Shizuku access: NOT GRANTED.\nYou can retry from the Shizuku menu."
            }
        }
    }

    private fun openDisplaySettings() {
        startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    }

    private fun openTouchSettings() {
        val intent = Intent(Settings.ACTION_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Use your device's touch/refresh settings for supported controls", Toast.LENGTH_LONG).show()
    }

    private fun openGameModeSettings() {
        try {
            startActivity(Intent("android.settings.GAME_SETTINGS"))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }
}
